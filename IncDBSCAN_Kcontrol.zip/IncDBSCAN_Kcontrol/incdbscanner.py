import matplotlib
from cluster import *
import numpy as np
import matplotlib.pyplot as plt 
from numpy import inf
from numpy import sqrt 


class incdbscanner:

    dataSet = []
    count = 0
    visited = []
    curCores = []
    newCores = []
    Clusters = []
    Outlier = 0
    num = 0

    def __init__(self):
        self.Outlier = cluster('Outlier')

    def incdbscan(
        self,
        D,
        eps,
        MinPts,
        K,
        ):


        Outlierpoints = []
        plt.figure(1)
        plt.title(r'INCREMENTAL DBSCAN Algorithm', fontsize=18)
        plt.xlabel(r'Dim 1', fontsize=17)
        plt.ylabel(r'Dim 2', fontsize=17)
        auxK = 0
        for point in D:
            self.dataSet.append(point)
            auxK += 1
            name = 'Cluster' + str(self.count)
            C = cluster(name)
            self.count += 1
            C.addPoint(point)
            self.curCores.append(point)
            self.Clusters.append(C)
            if(auxK == K):
                break
        D = D[K:]
        for point in D:
            self.dataSet.append(point)
            self.incrementalAdd(point, eps, MinPts)
            for core in self.newCores:
                if core not in self.curCores:
                    self.curCores.append(core)
        for clust in self.Clusters:
            plt.plot(clust.getX(), clust.getY(), 'o', label=clust.name)
        print ('Outlier \n')
        print (self.Outlier.getPoints())
        for Outlierp in self.Outlier.getPoints():
            Outlierpoints.append(Outlierp)
        for pts in Outlierpoints:
            print ('\nOutlier:' + str(Outlierpoints))
            print ('\nPoint:' + str(pts))
            for clust in self.Clusters:
                print ('Cluster Points ')
                clust.printPoints()
                if clust.has(pts):
                    print ('\n Point to REMOVE' + str(pts))
                    self.Outlier.remPoint(pts)    
        print ('Outlier 2 \n')
        print (self.Outlier.getPoints())
        if len(self.Outlier.getPoints()) > 0:
            plt.plot(self.Outlier.getX(), self.Outlier.getY(), 'o',
                 label='Outlier')
        print(self.count)         



        plt.grid(True)
        plt.margins(0.05)
        plt.show()
        while True:
            plt.figure(2)
            plt.clf()
            plt.title(r'INCREMENTAL DBSCAN After Deletion', fontsize=18)
            plt.xlabel(r'Dim 1', fontsize=17)
            plt.ylabel(r'Dim 2', fontsize=17)
            for clust in self.Clusters:
                clust.printPoints()
                plt.plot(clust.getX(), clust.getY(), 'o', label=clust.name)
       
            if len(self.Outlier.getPoints()) > 0:
                self.Outlier.printPoints()
                plt.plot(self.Outlier.getX(), self.Outlier.getY(), 'o',
                     label='Outlier')

            plt.legend(loc='lower left')
            plt.grid(True)
            plt.margins(0.05)
            plt.show()
    #___________________________________________________________________________________________________________________________________________________________________________________--
    def expandCluster(
        self,
        point,
        NeighbourPoints,
        C,
        eps,
        MinPts,
        ):
        self.visited = []

        C.addPoint(point)

        for p in NeighbourPoints:
            if p not in self.visited:
                self.visited.append(p)
                np = self.regionQuery(p, eps)
                if len(np) >= MinPts:
                    for n in np:
                        if n not in NeighbourPoints:
                            NeighbourPoints.append(n)

            for c in self.Clusters:
                if not c.has(p):
                    if not C.has(p):
                        C.addPoint(p)

            if len(self.Clusters) == 0:
                if not C.has(p):
                    C.addPoint(p)

        self.Clusters.append(C)
        print ('\n' + C.name + '\n')
        C.printPoints()
    #____________________________________________________________________________________________________________________________________________________________________________________
    def regionQuery(self, P, eps):
        result = []
        for d in self.dataSet:
            if float(((float(d[0]) - float(P[0])) ** 2 + (float(d[1]) - float(P[1])) ** 2) ** 0.5) <= float(eps):
                result.append(d)
        return result
    #_________________________________________________________________________________________________________________________________________________________________________________________
    def findNearestCluster(self, p):
        closest = self.curCores[0]
        for core in self.curCores:
            if(np.linalg.norm(core-p)< np.linalg.norm(closest-p)):
                closest = core
        return closest
    #___________________________________________________________________________________________________________________________________________________
    def incrementalAdd(
        self,
        p,
        eps,
        Minpts,
        ):
        self.num = self.num + 1
        print ('\nADDING point ' + str(self.num))
        self.visited = []
        self.newCores = []
        UpdSeedIns = []
        foundClusters = []
        NeighbourPoints = self.regionQuery(p, eps)
        #if the p has enough points in its neighborhood had it to the new core record 
        if len(NeighbourPoints) >= Minpts:
            self.newCores.append(p)
        self.visited.append(p)
        #visit the neighbors of p
        for pt in NeighbourPoints:
            #if the neighbor of the neighbor hasnt been visited before add it to the visited
            if pt not in self.visited:
                self.visited.append(pt)
                np = self.regionQuery(pt, eps)
                if len(np) >= Minpts:
                    #if the neighborhood of the neighbor is big enough add each of said neighbor of neighbors to the neighborhood of p
                    for n in np:
                        if n not in NeighbourPoints:
                            NeighbourPoints.append(n)
                    #if p neighbor with a big enough neighborhood isnt in the Core record add to the new core record        
                    if pt not in self.curCores:
                        self.newCores.append(pt)
        #for each pof these new cores                
        for core in self.newCores:
            corehood = self.regionQuery(core, eps)
            print ('the corehood is:', corehood)
            for elem in corehood:
                print ('The Minpts are:', Minpts)
                print (self.regionQuery(elem, eps))
                if len(self.regionQuery(elem, eps)) >= Minpts:
                    #had these new cores to the updateSeedList
                    if elem not in UpdSeedIns:
                        UpdSeedIns.append(elem)

        #if there are no points in UpdateSeedList p is an outlier
        if len(UpdSeedIns) < 1:
            self.Outlier.addPoint(p)
        else:
            #there are Seeds for the update
            findCount = 0
            #If any of the seed is in an already existate cluster update findcount, if said cluster isnt in found clusters add
            for seed in UpdSeedIns:
                for clust in self.Clusters:
                    if clust.has(seed):
                        findCount += 1
                        if clust.name not in foundClusters:
                            foundClusters.append(clust.name)
                            break
            #Creating a new cluster
            # if the seeds werent found in any existing cluster we need to create a new one          
            if len(foundClusters) == 0:
                smallest = self.Clusters[0]
                #First look for the smallest cluster already created
                for clust in self.Clusters:
                    if(clust.size() < smallest.size()):
                        smallest=clust
                #if the smallest cluster is smaller than the p cluster merge the smallest with its closest to        
                if(smallest.size() < len(UpdSeedIns)):
                    #-----Find the closest cluster to the smaller
                    closest1 = self.Clusters[0]
                    min_dist1 = inf
                    for pt in smallest.getPoints():
                        for clust in self.Clusters:
                            for point in clust.getPoints():
                                if( sqrt((pt[0]-point[0])**2 + (pt[1]-point[1])**2) <min_dist1):
                                    closest1 = clust
                                    min_dist1 = sqrt((pt[0]-point[0])**2 + (pt[1]-point[1])**2)
   
                 
                    #merge the smallest with its closest
                    for point in smallest.getPoints():                
                        closest1.addPoint(point)
                    self.Clusters.remove(smallest)
                    name = 'Cluster' + str(self.count)
                    C = cluster(name)
                    self.count += 1
                    self.expandCluster(UpdSeedIns[0],self.regionQuery(UpdSeedIns[0],eps), C, eps, Minpts)    
                else: 
                    #the smallest is bigger than the p cluster
                    # First check distances
                     min_dist2 = inf
                     for pt in smallest.getPoints():
                         for points in NeighbourPoints:
                             if(sqrt((pt[0]-points[0])**2 + (pt[1]-points[1])**2) <min_dist2):
                                 min_dist2 = sqrt((pt[0]-points[0])**2 + (pt[1]-points[1])**2)
                     #if the smallest is too far from p clust look for the closest to the smallest and look for the closest to the p cluster            
                     if(min_dist2 > 2*eps):
                        closest3 = self.Clusters[0]
                        min_dist3 = inf
                        for pt in smallest.getPoints():
                            for clust in self.Clusters:
                                for point in clust.getPoints():
                                    if( sqrt((pt[0]-point[0])**2 + (pt[1]-point[1])**2) <min_dist3):
                                        closest3 = clust
                                        min_dist3 = sqrt((pt[0]-point[0])**2 + (pt[1]-point[1])**2)
                        closest4 = self.Clusters[0]
                        min_dist4 = inf
                        for seed in UpdSeedIns:
                            for clust in self.Clusters:
                                for point in clust.getPoints():
                                    if( sqrt((seed[0]-point[0])**2 + (seed[1]-point[1])**2) <min_dist4):
                                        closest4 = clust
                                        min_dist4 = sqrt((seed[0]-point[0])**2 + (seed[1]-point[1])**2)
                        if(min_dist3 <= 2*eps):
                            #merger smallest with its closest                
                            for point in smallest.getPoints():
                                closest3.addPoint(point)
                            self.Clusters.remove(smallest)
                            name = 'Cluster' + str(self.count)
                            C = cluster(name)
                            self.count += 1
                            self.expandCluster(UpdSeedIns[0],self.regionQuery(UpdSeedIns[0],eps), C, eps, Minpts)
                        if(min_dist4 < 2*eps):
                            #merger p with its closest
                            for clusname in foundClusters:
                                for clus in self.Clusters:
                                    if clus.name == clusname:
                                        for cluspoints in clus.getPoints():
                                            if not closest4.has(cluspoints):
                                                closest4.addPoint(cluspoints)
                            if len(UpdSeedIns) > findCount:
                                for seed in UpdSeedIns:
                                    if not closest4.has(seed):
                                        closest4.addPoint(seed)
                     else:
                         #if the smallest is close enough to the p cluster merger p with smallest
                              #merger p with its closest
                            for clusname in foundClusters:
                                for clus in self.Clusters:
                                    if clus.name == clusname:
                                        for cluspoints in clus.getPoints():
                                            if not smallest.has(cluspoints):
                                                smallest.addPoint(cluspoints)
                            if len(UpdSeedIns) > findCount:
                                for seed in UpdSeedIns:
                                    if not smallest.has(seed):
                                        smallest.addPoint(seed)   

            #Adding a Point P to already existing cluster                      
            elif len(foundClusters) == 1:
                originalCluster = -1
                newCluster = -1
                for c in self.Clusters:
                    if c.name == foundClusters[0]:
                        originalCluster = c
                        newCluster = c
                newCluster.addPoint(p)
                #Replace with a need freshly made cluster
                if len(UpdSeedIns) > findCount:
                    for seed in UpdSeedIns:
                        if not newCluster.has(seed):
                            newCluster.addPoint(seed)
                self.Clusters.remove(originalCluster)
                self.Clusters.append(newCluster)
            else:
                #Merging clusters
                masterCluster = -1
                originalCluster = -1
                for c in self.Clusters:
                    if c.name == foundClusters[0]:
                        masterCluster = c
                        originalCluster = c
                for clusname in foundClusters:
                    for clus in self.Clusters:
                        if clus.name == clusname:
                            for cluspoints in clus.getPoints():
                                if not masterCluster.has(cluspoints):
                                    masterCluster.addPoint(cluspoints)
                if len(UpdSeedIns) > findCount:
                    for seed in UpdSeedIns:
                        if not masterCluster.has(seed):
                            masterCluster.addPoint(seed)
                self.Clusters.remove(originalCluster)
                self.Clusters.append(masterCluster)